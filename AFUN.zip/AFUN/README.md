AdminFun
========

A PocketMine plugin for trolling, punishing, broadcasting, messaging.  It gives fun to admins.
<br>This plugin ports most features from bukkit's AdminFun and it adds some custom features from hoyinm14mc's idea
